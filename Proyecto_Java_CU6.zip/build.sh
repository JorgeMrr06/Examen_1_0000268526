#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
mkdir -p build/classes dist
find src -name '*.java' -print > build/sources.txt
javac --release 17 -encoding UTF-8 -d build/classes @build/sources.txt
jar --create --file dist/cu6-comprar-producto.jar --main-class edu.itson.cu6.Main -C build/classes .
printf '%s\n' 'Compilación correcta: dist/cu6-comprar-producto.jar'
