﻿param([switch]$RunTests, [string]$EvidencePath)
$ErrorActionPreference = 'Stop'
Push-Location -LiteralPath $PSScriptRoot
try {
# Oracle javapath puede exponer java/javac sin jar. Resolver el JDK de java.
$ErrorActionPreference = 'Continue'
$taskJavaSettings = & java -XshowSettings:properties -version 2>&1 | ForEach-Object { $_.ToString() }
$ErrorActionPreference = 'Stop'
$taskHomeLine = $taskJavaSettings | Where-Object { $_ -match '^\s*java\.home\s*=' } | Select-Object -First 1
if (-not $taskHomeLine) { throw 'No se encontró Java. Instala JDK17 o superior y agrega su bin al PATH.' }
$taskJdkHome = ($taskHomeLine -replace '^\s*java\.home\s*=\s*', '').Trim()
$taskJavac = Join-Path $taskJdkHome 'bin/javac.exe'
$taskJar = Join-Path $taskJdkHome 'bin/jar.exe'
$taskJava = Join-Path $taskJdkHome 'bin/java.exe'
if (-not (Test-Path -LiteralPath $taskJavac)) { throw 'Se necesita un JDK17 o superior; un JRE solo no compila. Agrega el bin del JDK al PATH.' }
New-Item -ItemType Directory -Force -Path 'build/classes','build/test-classes','dist' | Out-Null
$taskSources = Get-ChildItem -LiteralPath 'src' -Recurse -Filter '*.java' | ForEach-Object FullName
& $taskJavac --release 17 -encoding UTF-8 -d 'build/classes' $taskSources
if ($LASTEXITCODE -ne 0) { throw 'La compilación falló. Verifica que utilices JDK17 o superior.' }
& $taskJar --create --file 'dist/cu6-comprar-producto.jar' --main-class 'edu.itson.cu6.Main' -C 'build/classes' .
if ($LASTEXITCODE -ne 0) { throw 'No se pudo crear el JAR.' }
Write-Host 'Compilación correcta: dist/cu6-comprar-producto.jar'
if ($RunTests -or $EvidencePath) {
    $taskTests = Get-ChildItem -LiteralPath 'test' -Recurse -Filter '*.java' | ForEach-Object FullName
    & $taskJavac --release 17 -encoding UTF-8 -cp 'build/classes' -d 'build/test-classes' $taskTests
    if ($LASTEXITCODE -ne 0) { throw 'No se pudieron compilar las pruebas.' }
}
if ($RunTests) {
    & $taskJava '-Dfile.encoding=UTF-8' '-Dstdout.encoding=UTF-8' '-Djava.awt.headless=true' -ea -cp 'build/classes;build/test-classes' 'edu.itson.cu6.ModelTests'
    if ($LASTEXITCODE -ne 0) { throw 'Fallaron las pruebas.' }
}
if ($EvidencePath) {
    & $taskJava '-Dfile.encoding=UTF-8' '-Dstdout.encoding=UTF-8' '-Djava.awt.headless=true' -cp 'build/classes;build/test-classes' 'edu.itson.cu6.ScreenshotHarness' $EvidencePath
    if ($LASTEXITCODE -ne 0) { throw 'Falló la demostración Swing.' }
}
} finally { Pop-Location }
