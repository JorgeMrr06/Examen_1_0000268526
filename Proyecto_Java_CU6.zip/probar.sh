#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
sh build.sh
mkdir -p build/test-classes
find test -name '*.java' -print > build/tests.txt
javac --release 17 -encoding UTF-8 -cp build/classes -d build/test-classes @build/tests.txt
java -Djava.awt.headless=true -ea -cp 'build/classes:build/test-classes' edu.itson.cu6.ModelTests
