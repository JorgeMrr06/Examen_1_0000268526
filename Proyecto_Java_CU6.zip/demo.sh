#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
sh probar.sh
java -Djava.awt.headless=true -cp 'build/classes:build/test-classes' edu.itson.cu6.ScreenshotHarness build/evidencia
