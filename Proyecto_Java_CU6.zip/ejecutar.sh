#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
[ -f dist/cu6-comprar-producto.jar ] || sh build.sh
java -jar dist/cu6-comprar-producto.jar
