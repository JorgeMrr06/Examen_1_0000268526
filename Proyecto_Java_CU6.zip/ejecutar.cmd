@echo off
pushd "%~dp0"
if not exist "dist\cu6-comprar-producto.jar" call build.cmd
if not exist "dist\cu6-comprar-producto.jar" exit /b 1
java -jar "dist\cu6-comprar-producto.jar"
popd
